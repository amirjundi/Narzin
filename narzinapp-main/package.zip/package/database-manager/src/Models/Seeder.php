<?php

namespace YoussefElghaly\DatabaseManager\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use YoussefElghaly\DatabaseManager\Traits\UsesDatabaseMangerConnection;

class Seeder extends Model
{
    use HasFactory ;


    /**
     * The attributes that are mass assignable.
     */
    protected $guarded = [];
    protected $connection = 'database_manager2';
    protected $table    = 'seeders';
    protected $primaryKey = 'id';



}
