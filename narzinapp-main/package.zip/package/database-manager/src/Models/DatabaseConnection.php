<?php

namespace YoussefElghaly\DatabaseManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use YoussefElghaly\DatabaseManager\Traits\UsesDatabaseMangerConnection;

// use Modules\DatabaseManager\Database\Factories\DatabaseConnectionFactory;

class DatabaseConnection extends Model
{
    use HasFactory ;

    protected $connection = 'database_manager2';
    protected $fillable = ['module_name', 'connection_name', 'host', 'database', 'username', 'password'];

    protected $hidden = ['password'];
}
