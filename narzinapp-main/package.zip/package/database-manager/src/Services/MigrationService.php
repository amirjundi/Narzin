<?php

namespace YoussefElghaly\DatabaseManager\Services;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use YoussefElghaly\DatabaseManager\Models\DatabaseConnection;

class MigrationService
{
    public static function migrateModule($moduleName)
    {
        try {
            $connection = DatabaseConnection::where('module_name', $moduleName)->first();
            if (!$connection) {
                throw new \Exception("No database connection found for module: $moduleName");
            }
            // config(["database.connections.{$moduleName}" => [
            //     'driver' => 'mysql',
            //     'host' => $connection->host,
            //     'database' => $connection->database,
            //     'username' => $connection->username,
            //     'password' => $connection->password,
            //     'charset' => 'utf8mb4',
            //     'collation' => 'utf8mb4_unicode_ci',
            // ]]);
            Artisan::call('module:migrate', ['module' => $connection->module_name, '--database' => $connection->connection_name]);
            return Artisan::output();
        } catch (\Exception $e) {
            Log::error("Migration Error for $moduleName: " . $e->getMessage());
            return "Error: " . $e->getMessage();
        }
    }

    public static function rollbackModule($moduleName)
    {
        $connection = DatabaseConnection::where('module_name', $moduleName)->first();
        if (!$connection) {
            throw new \Exception("No database connection found for module: $moduleName");
        }
        try {
            Artisan::call('module:migrate-rollback', ['module' => $connection->module_name, '--database' => $connection->connection_name]);
            return Artisan::output();
        } catch (\Exception $e) {
            Log::error("Rollback Error for $moduleName: " . $e->getMessage());
            return "Error: " . $e->getMessage();
        }
    }

    public static function listMigrationStatus($moduleName, $connection)
    {
        try {
            $command = Artisan::call('module:migrate-custom-status', ['module' => $moduleName, '--database' => $connection]);
            return Artisan::output();
        } catch (\Exception $e) {
            Log::error("Status Error for $moduleName: " . $e->getMessage());
            return "Error: " . $e->getMessage();
        }
    }
}
