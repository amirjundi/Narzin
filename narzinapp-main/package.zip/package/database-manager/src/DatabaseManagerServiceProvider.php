<?php 


namespace YoussefElghaly\DatabaseManager;


use Illuminate\Support\ServiceProvider;
use YoussefElghaly\DatabaseManager\Console\Commands\ModuleMigrationStatus;


class DatabaseManagerServiceProvider extends ServiceProvider
{
    public function boot()
    {
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'databasemanager');
        $this->loadMigrationsFrom(__DIR__.'/Database/migrations');

        if ($this->app->runningInConsole()) {
            $this->commands([
                ModuleMigrationStatus::class,
            ]);
        }
    }

    public function register()
    {
        $this->commands([
           ModuleMigrationStatus::class,
        ]);
    }
}