<?php

namespace YoussefElghaly\DatabaseManager\Traits;

trait UsesDatabaseMangerConnection
{
    protected static function bootUsesTaskConnection()
    {
        static::creating(function ($model) {
            $model->setConnection(config('databasemanager.database.connection'));
        });
    }

    public function getConnectionName()
    {
        return config('databasemanager.database.connection');
    }
}